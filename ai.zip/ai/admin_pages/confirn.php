<?php
// Connect to the database
$host='localhost';
$username='root';
$possword='';
$database_name='e-cemmerce';
$conn = mysqli_connect($host,$username,$possword,$database_name);
?>