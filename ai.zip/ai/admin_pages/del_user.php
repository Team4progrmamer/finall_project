<?php
include('./confirn.php');
$ID=$_GET['id'];
mysqli_query($conn,"DELETE FROM user_form WHERE id=$ID");
header('Location: web.php');
?>