<?php
// Database credentials
include('./confirn.php');
$show=mysqli_query($conn,"SELECT * FROM products");
function showProducts($show) {
  while ($information = mysqli_fetch_array($show)) {
    echo "
      <div class='col-4'>
      <img src='{$information['image']}'>
        <h4>{$information['name']}</h4>
        <div class='rating'>
          <i class='fa fa-star'></i>
          <i class='fa fa-star'></i>
          <i class='fa fa-star'></i>
          <i class='fa fa-star'></i>
          <i class='fa fa-star'></i>
        </div>
        <p>{$information['price']}</p>
        <a href='modif.php? id=$information[id]' name='modifiyt' tagret='_black' class='btn'>Modifiate a product</a>
        <a href='delete.php? id=$information[id]' name='delete'  class='btn'>Delete a product</a>

      </div>
    ";
  }
}
$show1=mysqli_query($conn,"SELECT * FROM user_form");
// function to display the user
function showuser($show1) {
  // Check if there are any rows returned
  if (mysqli_num_rows($show1) > 0) {
      // Output data of each row
      while($row = mysqli_fetch_array($show1)) {
          
        // Display the product details
        if ($row['user_type']=="user"){
        echo "<tr>
                  <td>
                      <div class='cart-info'>                      
                         
              </tr>";
              echo "<tr>
              <td>
                  <div class='cart-info'>
                      <div>
                      <p>{$row['name']}</p>
                      <a href='del_user.php?id={$row['id']}'>Remove</a>
                  </div>
              </div>
          </td>
          <td>
              <label>{$row['email']}</label>
          </td>
          <td>{$row['password']}</td>          </tr>";
      }
      }
  } else {
      echo "No user found.";
  }
}
// function to display the admin
function showadmin($show1) {
  // Check if there are any rows returned
  if (mysqli_num_rows($show1) > 0) {
      // Output data of each row
      while($row = mysqli_fetch_array($show1)) {
          
        // Display the product details
        if ($row['user_type']=="admin"){
        echo "<tr>
                  <td>
                      <div class='cart-info'>                      
                         
              </tr>";
              echo "<tr>
              <td>
                  <div class='cart-info'>
                      <div>
                      <p>{$row['name']}</p>
                      <a href='del_user.php?id={$row['id']}'>Remove</a>
                  </div>
              </div>
          </td>
          <td>
              <label>{$row['email']}</label>
          </td>
          <td>{$row['password']}</td>          </tr>";
      }
      }
  } else {
      echo "No user found.";
  }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Page Admin </title>
    <link rel="stylesheet" href="web.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"  />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css">
</style>
</head>
<body>
<!---------------------- Menu nav bar ------------------->

  <div class="header">
    <div class="container">
   <div class="navbar">
<div class="logo">
   <img src="/ai/images/logo.png" width="125px" >
</div>
<nav>

  <ul id="menuitems">
  <li><a href="/ai/index.php">Home</a></li>
<li><a href="/ai//all_product.php">Produts</a></li>
<li><a href="/ai/FORMECONTACT\index.php">Contact</a></li>
<li><a href="/ai//about us.html">About</a></li>
<li><a href="/ai/Login Form/login_form.php">Account</a></li>
  
</ul>
</nav>
<img src="/ai/images/cart.png" width="35px" height="35px" class="aid">
<img src="/ai/images/menu.png" class="menu-icon" onclick="menutoggle()">
</div>





<div class="row">

<div class="col-2">

  <div class="wrapper">
    <div class="static-txt">I'm a How Product </div>
    <ul class="dynamic-txts">
      <li><span>DELETE</span></li>
      <li><span>ADD</span></li>
      <li><span>MODIFIY</span></li>
    </ul>
  </div>
  <div class="wrapper">
    <div class="static-txt">I'm a How user</div>
    <ul class="dynamic-txts">
      <li><span>ADD</span></li>
      <li><span>DELETE</span></li>
    </ul>
  </div>
</div>
</div>
   </div>
  </div>
<h2 class="title">Pruduct</h2>
<div class="row">

<!-- php place -->
 <?php
$show=mysqli_query($conn,"SELECT * FROM products");
showProducts($show);
      ?>

</div>
<!---- offers--->
<div class="offer">
  <div class="small-container">
    <div class="row">
      <div class="col-2">
        <h1 class="text" style="color: red;"> Users</h1>
      </div>
    </div>
  </div>
</div>
<div class="row">
<!-- php place -->
<div class="small-container cart-page">
    <table>
        <tr>
            <th>Name</th>
            <th>Gmail</th>
            <th class="yah">Possword</th>
            <th></th>
        </tr>
        <td>
            <!-- Place To Show Users -->
<?php
$show1=mysqli_query($conn,"SELECT * FROM user_form");
showuser($show1);
     ?>            
        </td>
    </table>

</div>
</div>
<center> 
<!------Brands------->
<div class="brands">
  <h2 class="title">Add New Admin</h2>
  <?php echo "<a href='./Login Form/register_form.php' name='add' tagret='_black' class='btn'>Add A Admin</a>" ?>
</div>
</center>
<!---- offers--->
<div class="offer">
  <div class="small-container">
    <div class="row">
      <div class="col-2">
        <h1 class="text" style="color: red;"> Admin</h1>
      </div>
    </div>
  </div>
</div>
<div class="row">
<!-- php place -->
<div class="small-container cart-page">
    <table>
        <tr>
            <th>Name</th>
            <th>Gmail</th>
            <th class="yah">Possword</th>
            <th></th>
        </tr>
        <td>
            <!-- Place To Show Users -->
            <?php
$show1=mysqli_query($conn,"SELECT * FROM user_form");
showadmin($show1);
     ?>           
        </td>
    </table>

</div>
</div>
<center> 
<!------Brands------->
<div class="brands">
  <h2 class="title">Add New Pruduct</h2>
  <?php echo "<a href='./add_prouduct.php' name='add' tagret='_black' class='btn'>Add A Admin</a>" ?>
</div>
</center>
<!----------- Footer ----------->
<div class="footer">
  <div class="container">
    <div class="row">
      <div class="footer-col-1">
        <h3>Download Our App</h3>
        <p>Download App for Android and ios mobile phone.</p>
        <div class="app-logo">
          <img src="/ai/images/app-store.png" >
          <img src="/ai/images/play-store.png" >
        </div>
      </div>
      <div class="footer-col-2">
        <img src="/ai/images/logo.png" >
        <p>Our Purpose Is To Sustainably Make the Pleasure and
          Benefits of Sports Accessible to the Many.</p>
      </div>
      <div class="footer-col-3">
        <h3>Useful Links</h3>
        <ul>
          <li>Coupons</li>
          <li>Blog Post</li>
          <li>Return Policy</li>
          <li>Join affiliate</li>
        </ul>
      </div>
      <div class="footer-col-4">
        <h1>Follow Us</h1>
        <ul>
          <li><a href=" https://www.google.com/search?client=firefox-b-d&q=icons+code+html" class="social"> <img src="/ai/images/facebook.png" alt="" width="25px" height="25px"> </a></li>
          <li><a href="" class="social"> <img src="/ai/images/instagram.png" alt="" width="25px" height="25px"> </a></li>
          <li><a href="" class="social"> <img src="/ai/images/telegram.png" alt="" width="25px" height="25px" > </a></li>
          <li><a href="" class="social"> <img src="/ai/images/twitter.png" alt=""  width="25px" height="25px"> </a></li>
        </ul>
      </div>
    </div>
    <hr> <!----ndiro biha khat -->
    <p class="copyright">Copyright 2023 -Team4progrmamer</p>
  </div>
</div>

<!------- jr for toggle menu -->
<script>
var menuitems=document.getElementById("menuitems");
menuitems.style.maxHeight="0px";
function menutoggle(){
if(menuitems.style.maxHeight == "0px")
{
  menuitems.style.maxHeight="200px";
}
else{
  menuitems.style.maxHeight="0px";
}}
</script>
</body>
</html>