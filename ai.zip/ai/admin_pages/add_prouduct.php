<html>
<head>
    <title>Add Product</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Add Product</h1>
        <form action="" method="POST" enctype="multipart/form-data">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" required>
            <label for="description">Description</label>
            <textarea id="description" name="description" required></textarea>
            <label for="price">Price</label>
            <input type="number" id="price" name="price" step="0.5" min="0" required>
            <label for="price">Quantity</label>
            <input type="number" id="quantity" name="quantity" step="1" min="0" required>
            <label for="image">Image 1</label>
            <input type="file" id="image" name="image" accept="image/*"  required>
            <input type="submit" value="Submit" name='upload'>
            <input type="reset" value="Reset">
        </form>
    </div>
   
</body>
</html>
<?php
// Connect to the database
include ('./confirn.php');
// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// get the form data

if(isset($_POST['upload']))
{
    $NAME=$_POST['name'];
    $description=$_POST['description'];
    $PRICE=$_POST['price'];
    $QUANTITY=$_POST['quantity'];
    //image 1
    $image_location=$_FILES['image']['tmp_name'];
    $image_name=$_FILES['image']['name'];
    $image_up="../uploads/".$image_name;
    
    // Check if all four images are uploaded
    if(move_uploaded_file($image_location,$image_up))
    {
        // Insert the data into the database
        $reqette_insert="INSERT INTO products(name,description,price,Quntity,image) VALUES('$NAME','$description','$PRICE','$QUANTITY','$image_up')";
        mysqli_query($conn,$reqette_insert);

        // Display success message
        echo "<script> alert('All images uploaded successfully') </script>";
    }
    else 
    {
        // Display error message
        echo "<script> alert('Failed to upload one or more images') </script>";
    }

    // Redirect to the add_prouduct.php page
    header('location: add_prouduct.php');
}

// Close the connection
mysqli_close($conn);
?>