<?php
// Connect to the database
include ('./confirn.php');
// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// get the form data

if(isset($_POST['upload']))
{
    $ID=$_POST['id'];
    $NAME=$_POST['name'];
    $description=$_POST['description'];
    $PRICE=$_POST['price'];
    $QUANTITY=$_POST['quantity'];
    //image 1
    $image_location=$_FILES['image']['tmp_name'];
    $image_name=$_FILES['image']['name'];
    $image_up="../uploads/".$image_name;

    // Check if all four images are uploaded
    if(move_uploaded_file($image_location,$image_up))
    {
        // Insert the data into the database
        $reqette_update="UPDATE products SET  name='$NAME',description='$description',price='$PRICE',Quntity='$QUANTITY',image='$image_up'  where id=$ID";
        mysqli_query($conn,$reqette_update);
        // Display success message
        echo "<script> alert('All images uploaded successfully') </script>";
    }
    else 
    {
        // Display error message
        echo "<script> alert('Failed to upload one or more images') </script>";
    }

    // Redirect to the add_prouduct.php page
    header('location: web.php');
}

// Close the connection
mysqli_close($conn);
?>