<?php
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';

// verify that all input post 
if (isset($_POST['name']) && $_POST['name'] != '' && 
    isset($_POST['email']) && $_POST['email'] != '' && 
    filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) &&
    isset($_POST['subject']) && $_POST['subject'] != '' && 
    isset($_POST['message']) && $_POST['message'] != '') 
{ 
    // save input 
    $username = $_POST['name'];
    $userEmail = $_POST['email'];
    $messagesubject = $_POST['subject'];
    $message = $_POST['message'];

    //PHPMailer object
    $mail = new PHPMailer\PHPMailer\PHPMailer; 
    $mail->isSMTP();     
    $mail->Host = 'smtp.gmail.com';     
    $mail->SMTPAuth = true;     
    $mail->Username = 'dzshoopwebsite@gmail.com';     
    $mail->Password = 'iadoiohlfyrnoxug';     
    $mail->SMTPSecure = 'ssl';    
    $mail->Port = 465;

    //email content
    $mail->setFrom($_POST['email'],$username,$username);
    $mail->addAddress('dzshoopwebsite@gmail.com'); 
    $mail->Subject = $messagesubject;
    $mail->msgHTML($message); 

    if(!$mail->send()) 
    {
        echo "Message could not be sent.";
        echo "Mailer Error: " . $mail->ErrorInfo;
    } 
    else 
    {
        echo "<script>alert('Message sent successfully.')</script>";
    }
 }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form</title>
    <link rel="stylesheet" href="web.css">
    <link rel="stylesheet" href="style.css" media="all">
   
    <script src="../web.js"></script>
</head>
<body>
    <!---------------------- Menu nav bar ------------------->


  <div class="header">
    <div class="container">
   <div class="navbar">
<div class="logo">
   <img src="logo.png" width="125px" >
</div>
<nav>

  <ul id="menuitems">
    <li><a href="../web.php">Home</a></li>
    <li><a href="../all_product.php">Produts</a></li>
    <li><a href=".\FORMECONTACT\index.php">Contact</a></li>
    <li><a href="../about us.html">About</a></li>
    <li><a href="../Login Form/login_form.php">Account</a></li>
  </ul>
</nav>
<img src="cart.png" width="35px" height="35px" class="aid">
<img src="menu.png" class="menu-icon" onclick="menutoggle()">
</div>

<!-- form send email -->
<div class="test">
    <div class="container1">
        <form method="POST" action="" class="form">
            <!-- form content -->
            <div class="form-group">
                <label for="name" class="form-label">Your Name</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Username" tabindex="1" required>
            </div>
            <div class="form-group">
                <label for="email" class="form-label">Your Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Email" tabindex="2" required>
            </div>
            <div class="form-group">
                <label for="subject" class="form-label">Subject</label>
                <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" tabindex="3" required>
            </div>
            <div class="form-group">
                <label for="message" class="form-label">Message</label>
                <textarea class="form-control" rows="5" cols="50" id="message" name="message" placeholder="Enter Message..." tabindex="4"></textarea>
            </div>
            <div>
                <button type="submit" class="btn">Send Message!</button>
                <a href="../all-pages/web.html" target="_blank"><button type="button" class="btn">Go Home</button></a>
            </div>
        </form>
    </div>
  </div>
    
    <!----------- Footer ----------->
 <div class="footer">
  <div class="container">
    <div class="row">
      <div class="footer-col-1">
        <h3>Download Our App</h3>
        <p>Download App for Android and ios mobile phone.</p>
        <div class="app-logo">
          <img src="app-store.png" >
          <img src="play-store.png" >
        </div>
      </div>
      <div class="footer-col-2">
        <img src="logo.png" >
        <p>Our Purpose Is To Sustainably Make the Pleasure and
          Benefits of Sports Accessible to the Many.</p>
      </div>
      <div class="footer-col-3">
        <h3>Useful Links</h3>
        <ul>
          <li>Coupons</li>
          <li>Blog Post</li>
          <li>Return Policy</li>
          <li>Join affiliate</li>
        </ul>
      </div>
      <div class="footer-col-4">
        <h1>Follow Us</h1>
        <ul>
          <li><a href=" https://www.google.com/search?client=firefox-b-d&q=icons+code+html" class="social"> <img src="facebook.png" alt="" width="25px" height="25px"> </a></li>
          <li><a href="" class="social"> <img src="instagram.png" alt="" width="25px" height="25px"> </a></li>
          <li><a href="" class="social"> <img src="telegram.png" alt="" width="25px" height="25px" > </a></li>
          <li><a href="" class="social"> <img src="twitter.png" alt=""  width="25px" height="25px"> </a></li>
        </ul>
      </div>
    </div>
    <hr> <!----ndiro biha khat -->
    <p class="copyright">Copyright 2023 -Team4progrmamer</p>
  </div>
</div>  
<!------- jr for toggle menu -->
<script>
var menuitems=document.getElementById("menuitems");
menuitems.style.maxHeight="0px";
function menutoggle(){
if(menuitems.style.maxHeight == "0px")
{
  menuitems.style.maxHeight="200px";
}
else{
  menuitems.style.maxHeight="0px";
}}
</script>
</body>
</html>