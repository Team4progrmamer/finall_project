<?php 
 if (isset($_POST['submit'])) {
    $name=$_POST['name'];
    $subject=$_POST['subject'];
    $mailform=$_POST['mail'];
    $message=$_POST['message'];

    
    $mailto="dzshoopwebsite@gmail.com";
    $heders= "From : ".$mailform;
    $txt= "You have recrived an e-mail from".$name.".\n\n".$message;
    mail($mailto,$subject,$txt,$heders);

    header("Location: index.php?mailsend");
}

?>