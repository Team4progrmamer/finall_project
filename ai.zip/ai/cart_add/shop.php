<!-- show product -->
<?php
// Database credentials
include('../admin_pages/confirn.php');
$show=mysqli_query($conn,"SELECT * FROM products");
function showProducts($show) {
  while ($information = mysqli_fetch_array($show)) {
    echo "
      <div class='col-4'>
        <img src='../uploads/{$information['image']}' alt='{$information['image']}'>
        <h4>{$information['name']}</h4>
        <div class='rating'>
          <i class='fa fa-star'></i>
          <i class='fa fa-star'></i>
          <i class='fa fa-star'></i>
          <i class='fa fa-star'></i>
          <i class='fa fa-star'></i>
        </div>
        <p>{$information['price']}</p>
        <a href='val.php? id=$information[id]'   class='btn' target='_blan'>add to cart</a>

      </div>
    ";
  }
}
// Close the connection
mysqli_close($conn);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Dz-Shopping</title>
    <link rel="stylesheet" href="../web.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"  />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css">
</style>
</head>
<body>
<!---------------------- Menu nav bar ------------------->

  <div class="header">
    <div class="container">
   <div class="navbar">
<div class="logo">
   <img src="../Images/logo.png" width="125px" >
</div>
<nav>

  <ul id="menuitems">
  <li><a href="../index.php">Home</a></li>
    <li><a href="../all_product.php">Produts</a></li>
    <li><a href="..\FORMECONTACT\index.php">Contact</a></li>
    <li><a href="../about us.html">About</a></li>
    <li><a href="../Login Form/login_form.php">Account</a></li>
  <li><a href="card.php" target="_blank">My Card</a></li>
  </ul>
</nav>
<img src="../Images/cart.png" width="35px" height="35px" class="aid">
<img src="../Images/menu.png" class="menu-icon" onclick="menutoggle()">
</div>





<div class="row">

<div class="col-2">

  <div class="wrapper">
    <div class="static-txt">I'm a</div>
    <ul class="dynamic-txts">
      <li><span>YouTuber</span></li>
      <li><span>Designer</span></li>
      <li><span>Developer</span></li>
      <li><span>Freelancer</span></li>
    </ul>
  </div>
<a href="" class="btn">SHOP NOW   &#187;</a>
</div>

<div class="col-2">
<img src="../Images/image1.png" height="550px" width="300px" >
</div>
</div>
   </div>
  </div>
<h2 class="title">NEW ARRIVALS</h2>
<div class="row">

<!-- php place -->
 <?php
include('../admin_pages/confirn.php');

$show=mysqli_query($conn,"SELECT * FROM products");

showProducts($show);
      ?>

</div>
<!---- offers--->
<div class="offer">
  <div class="small-container">
    <div class="row">
      <div class="col-2">
        <img src="../Images/salee.png" class="offer-img">
      </div>
      <div class="col-2">
        <p> LOREM IPSUM DOLOR SIT AMET , CONSECTETUR ADIOISCING ELIT</p>
        <h1 class="text" style="color: red;"> EXTRA <big>20% OFF</big></h1>
        <p>
          SPECIAL OFFER
        </p> 
        <a href="" class="btn"> SHOW NOW &#187; </a>
      </div>
    </div>
  </div>
</div>
<h2 class="title">NEW ARRIVALS</h2>
<div class="row">
<!-- php place -->
 <?php
include('../admin_pages/confirn.php');

 $show=mysqli_query($conn,"SELECT * FROM products");
 
 showProducts($show);
       ?>
 

      

</div>
<!---- offers--->
<div class="offer">
  <div class="small-container">
    <div class="row">
      <div class="col-2">
        <img src="../Images/test2.png" class="offer-img" alt="right" width="100px" height="500px">
      </div>
      <div class="col-2">
        <p> Exclusively Available on Dz-Shoping</p>
        <h1 class="text" style="color: rgb(171, 14, 14);"> Extra <big >20% Off</big></h1>
        <small>The Mi Smart Band 4 4 features a 39.9% larger
          (than Mi Band 3) AMOLED color ful-touch display with
          adjustable brightness, so everything is clear as can
          be .</small> <br>
        <a href="" class="btn"> Shop Now &#187; </a>
      </div>
    </div>
  </div>
</div>
 <!------Brands------->
<div class="brands">
  <h2 class="title">Our Best Sellers</h2>
  <div class="small-container">
    <div class="row">
      <div class="col-5">
        <img src="../Images/sony.png" >
      </div>
      <div class="col-5">
        <img src="../Images/acer.png" >
      </div>
      <div class="col-5">
        <img src="../Images/intel.png">
      </div>
      <div class="col-5">
        <img src="../Images/sam.png" >
      </div>
      <div class="col-5">
        <img src="../Images/hp .png" >
      </div>
    </div>
  </div>
</div>
<!----------- Footer ----------->
<div class="footer">
  <div class="container">
    <div class="row">
      <div class="footer-col-1">
        <h3>Download Our App</h3>
        <p>Download App for Android and ios mobile phone.</p>
        <div class="app-logo">
          <img src="../Images/app-store.png" >
          <img src="../Images/play-store.png" >
        </div>
      </div>
      <div class="footer-col-2">
        <img src="../Images/logo.png" >
        <p>Our Purpose Is To Sustainably Make the Pleasure and
          Benefits of Sports Accessible to the Many.</p>
      </div>
      <div class="footer-col-3">
        <h3>Useful Links</h3>
        <ul>
          <li>Coupons</li>
          <li>Blog Post</li>
          <li>Return Policy</li>
          <li>Join affiliate</li>
        </ul>
      </div>
      <div class="footer-col-4">
        <h1>Follow Us</h1>
        <ul>
          <li><a href="https://www.google.com/search?client=firefox-b-d&q=icons+code+html" class="social"> <img src="../Images/facebook.png" alt="" width="25px" height="25px"> </a></li>
          <li><a href="" class="social"> <img src="../Images/instagram.png" alt="" width="25px" height="25px"> </a></li>
          <li><a href="" class="social"> <img src="../Images/telegram.png" alt="" width="25px" height="25px" > </a></li>
          <li><a href="" class="social"> <img src="../Images/twitter.png" alt=""  width="25px" height="25px"> </a></li>
        </ul>
      </div>
    </div>
    <hr> <!----ndiro biha khat -->
    <p class="copyright">Copyright 2023 - Team4progrmamer</p>
  </div>
</div>
<!------- jr for toggle menu -->
<script>
var menuitems=document.getElementById("menuitems");
menuitems.style.maxHeight="0px";
function menutoggle(){
if(menuitems.style.maxHeight == "0px")
{
  menuitems.style.maxHeight="200px";
}
else{
  menuitems.style.maxHeight="0px";
}}
</script>
</body>
</html>