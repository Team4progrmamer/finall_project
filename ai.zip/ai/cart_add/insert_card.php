<?php 
include('../admin_pages/confirn.php');

// verify of information came 
if (isset($_POST['add'])) {
    $NAME=$_POST['name'];
    $PRICE=$_POST['price'];
    $Quntity=$_POST['quantity'];
    $IMAGE=$_POST['image'];
    $insert= "INSERT INTO addcard (name,price,quntity,image) VALUES ('$NAME','$PRICE','$Quntity','$IMAGE')";
    mysqli_query($conn,$insert);
    // Close the connection
mysqli_close($conn);

    header('Location: card.php');

}

?>