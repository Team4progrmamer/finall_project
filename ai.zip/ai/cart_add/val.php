<?php
include('../admin_pages/confirn.php');

$ID=$_GET['id'];
// reqette to sherach about id product
$up=mysqli_query($conn,"SELECT * FROM products WHERE id=$ID");
$data= mysqli_fetch_array($up);
// Close the connection
mysqli_close($conn);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation product N° <?php echo $_GET['id']?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"  />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css">
    <style>
    
.main{
width:30%;
height: 60%;
padding: 200px;
box-shadow: 1px 1px 10px silver;
margin-top: 50px;
    }
    button{
        width: 250px;
        height: 50px;
        background: gold;
        border-top-left-radius: 5%;
        border-top-right-radius: 5%;
        border-bottom-left-radius: 5%;
        border-bottom-right-radius: 5%;
        border: none;
        transition: 0.2s ease;
        cursor: pointer;
        
    }
        a{

           margin-bottom: -100px;
        width: 250px;
        height: 50px;
        background:darkgoldenrod;
        border-top-left-radius: 5%;
        border-top-right-radius: 5%;
        border-bottom-left-radius: 5%;
        border-bottom-right-radius: 5%;
        border: none;
        transition: 0.2s ease;
        cursor: pointer;
        
    }
    button:hover ,a:hover{
    box-shadow: 20px 20px 30px rgba(100, 68, 68, 0.658);
    transform: translateY(-20px);
    }
    label{
        font-size: 15px;
        font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;

    }
    input{
        width: 100%;
        margin-bottom: -100px;
        width: 250px;
        height: 50px;
        background:darkgoldenrod;
        border-top-left-radius: 5%;
        border-top-right-radius: 5%;
        border-bottom-left-radius: 5%;
        border-bottom-right-radius: 5%;
        border: none;
        transition: 0.2s ease;
        cursor: pointer;
        background: gray;
    }
    .info{display: none;}
</style>
</head>
<body>
<!---------------------- Menu nav bar ------------------->
<center>
<div class="main">
    <form action="./insert_card.php" method="post">
        <h2>Did You Need  To Confirmation to purchase a product N° <?php echo $_GET['id']?></h2>
        <br><br><br>
        <div class="info">
        <input type="text" name="id" value='<?php echo $data['id']?>'>
        <input type="text" name="name" value='<?php echo $data['name']?>'>
        <input type="text" name="price" value='<?php echo $data['price']?>'>
        <input type="text" name="image" value='<?php echo $data['image']?>'>
        </div>
        <label for="price">Give me  Quantity  Of Product <?php echo $data['name']?> { between 0 and  <?php echo $data['Quntity']?> }    </label>
           <br><br><br> <input type="number" id="quantity" name="quantity" step="1" min="0" max='<?php echo $data['Quntity']?>' required>
            <br><br><br>
            <button name="add" type="submit">Confirmation to purchase a product </button>
            <br><br><br>
        <a href="shop.php"> Return To main </a>
    
    </form>
</div>
</center>
</body>
</html>