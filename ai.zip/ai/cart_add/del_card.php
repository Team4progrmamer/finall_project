<?php
include('../admin_pages/confirn.php');

$ID=$_GET['id'];
mysqli_query($conn,"DELETE FROM addcard WHERE id=$ID");
header('Location: card.php');
// Close the connection
mysqli_close($conn);

?>